var Rx = require('rx');

Rx.Observable
    .of()
    .subscribe((i)=>console.log(i));